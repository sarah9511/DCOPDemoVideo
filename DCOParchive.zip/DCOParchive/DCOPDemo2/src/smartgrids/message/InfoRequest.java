package smartgrids.message;

import java.io.Serializable;

@SuppressWarnings("serial")
public class InfoRequest implements Serializable
{
	
}
