package smartgrids.message;

import java.io.Serializable;

@SuppressWarnings("serial")
public class KillMessage implements Serializable
{
	
}
