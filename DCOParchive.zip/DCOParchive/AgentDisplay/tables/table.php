
<p>
<?php
	//echo 'in php program';
	$serverName = "127.0.0.1";
	$userName = "root";
	$password = "Embroideryfloss8";
	$dbname = "DCOP";
	$port = "3306";
        //now we make a connection using the information above
	//echo '<p> got here1 </p>';

	$conn = new mysqli($serverName, $userName, $password, $dbname, $port);
	//echo '<p> got here </p>';
	if($conn->connect_error){
		die("Connection failed: " . $conn->connect_error);
		echo '<p> Connection failed</p>';
	}//closing if
	//echo 'sucessfull connection'
	
?>
</p>
 <?php
	$vn = "a1";
	//echo '<p> var name is ' . $vn . ' </p>';
	agentTable($vn, $conn);
?>

<?php
function agentTable($name, $c){
	//storing the query to get all distinct agent names
	$sql = "SELECT varName, varVal FROM agents where agentName = '".$name . "';";
	//print($sql);
	$ra=  array();
	$result = mysqli_query($c, $sql) or die ("Got into query error");
	while($row = mysqli_fetch_assoc($result)){
		//$id = array_shift($row);
		$data[] = $row;
	}//closing while

	//print_r($data);
	echo '<h1><b>Agent: '.$name.'</b><br></br>';
	print("\n\n\n");	
	echo '<table border = "1" cellpadding = "5" cellspacing="5">';
	echo '<tbody>';
	echo '<tr> <td nowrap> Variable Name </td> <td nowrap> Value </td> </tr>';
	foreach($data as $key => $index){
	
		echo '<tr>';
		
		
			foreach($index as $key1 => $index1){
				echo'<td nowrap>' . $index1 . '</td>';
		
			}//closing for 
	
		echo '</tr>';
	
	}//closing for loop
	echo '</tbody></table>';
	
	return;
}//closing agentTable


?>
