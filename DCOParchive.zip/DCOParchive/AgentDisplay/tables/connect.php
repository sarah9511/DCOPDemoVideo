//<h1>connecting to database</h1>
<p>
<?php
	//echo 'in php program';
	$serverName = "127.0.0.1";
	$userName = "root";
	$password = "Embroideryfloss8";
	$dbname = "DCOP";
	$port = "3306";
        //now we make a connection using the information above
	//echo '<p> got here1 </p>';

	$conn = new mysqli($serverName, $userName, $password, $dbname, $port);
	//echo '<p> got here </p>';
	if($conn->connect_error){
		die("Connection failed: " . $conn->connect_error);
		echo '<p> Connection failed</p>';
	}//closing if
	//echo 'sucessfull connection'
	
?>
</p>