<!DOCTYPE html>

<html>
<head>
	<title>Agent Monitor</title>
	<link rel = "stylesheet" href="css/styles.css" />
</head>
<body>

	<link rel = "stylesheet" href="css/styles.css" />
	<div id="content">
	</div>
	<div id ="tab">
	</div>
	<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
	<script src="js/global.js"></script>
	
	

</body>
</html>
