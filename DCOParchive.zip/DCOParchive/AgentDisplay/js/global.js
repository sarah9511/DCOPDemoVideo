$(document).ready(function(){
	//initial load	- connect to the database
	//$("#content").load('tables/connect.php');
	
	//refresh table separately
	setInterval(function(){

		$('#tab').load('tables/table.php');	

	}, 1000);

});